note5
=====

note5 - simple, pure HTML5 plain text editor.

##Compatible Web Browser##
* Chrome (and also webkit based web browser)

##Features##
* Open file
* Download file

##Screenshot##
![note5](http://html5.web.id/note5/ss.png)

##Demo##
[Demo](http://html5.web.id/note5/)

##To Do##
* Others web browser compatibilty
* Find and replace function

##Maintainer##
* Fitra Aditya (fitra@g.pl)
